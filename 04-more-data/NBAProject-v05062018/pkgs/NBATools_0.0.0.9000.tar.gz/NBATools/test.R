library(NBATools)

# test for salary pred
player1 <- "Stephen Curry"
player2 <- "LeBron James"
player3 <- "Jamal Crawford"
player4 <- "Terrence Ross"
print(player1)
print(salaryPred(player1))
print(player2)
print(salaryPred(player2))
print(player3)
print(salaryPred(player3))
print(player4)
print(salaryPred(player4))


# test for game pred
warriors = c("Stephen Curry", "Kevin Durant", "Klay Thompson", "Draymond Green", "Andre Iguodala", "Shaun Livingston", "Nick Young", "Zaza Pachulia", "David West", "JaVale McGee", "Omri Casspi", "Kevon Looney", "Damian Jones", "Patrick McCaw", "Jason Thompson", "Jordan Bell")
cavaliers = c("LeBron James", "Kevin Love", "George Hill", "Tristan Thompson", "J.R. Smith", "Jordan Clarkson", "Kyle Korver", "Cedi Osman", "Rodney Hood", "Jose Calderon", "Jeff Green", "Ante Zizic", "Larry Nance", "Okaro White", "Marcus Thornton")
print("Warriors VS Cavaliers")
print(gamePred(warriors, cavaliers))
print("Cavaliers VS Warriors")
print(gamePred(cavaliers, warriors))

# test for team quality pred
print("Warriors")
print(teamQualityPred(warriors, 1000))
print("Cavaliers")
print(teamQualityPred(cavaliers, 1000))
